// SPDX-License-Identifier: GPL-2.0-only
/*
 * The mainline GS101 port boots unsigned AoC firmware directly and does not
 * have Google's GSA/Trusty firmware authentication service.  AoC still
 * references the API in the optional DT-controlled signed-firmware path, so
 * provide explicit unavailable stubs to keep the module self-contained.
 */
#include <linux/device.h>
#include <linux/errno.h>
#include <linux/gsa/gsa_aoc.h>

int gsa_load_aoc_fw_image(struct device *gsa, dma_addr_t img_meta,
			  phys_addr_t img_body)
{
	return -EOPNOTSUPP;
}

int gsa_unload_aoc_fw_image(struct device *gsa)
{
	return -EOPNOTSUPP;
}

int gsa_send_aoc_cmd(struct device *gsa, enum gsa_aoc_cmd cmd)
{
	return -EOPNOTSUPP;
}
