savedcmd_boot_device_spi.mod := printf '%s\n'   boot_device_spi.o | awk '!x[$$0]++ { print("./"$$0) }' > boot_device_spi.mod
