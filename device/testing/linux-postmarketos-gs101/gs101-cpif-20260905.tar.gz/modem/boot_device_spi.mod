./boot_device_spi.o
