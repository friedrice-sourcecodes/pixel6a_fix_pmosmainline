savedcmd_modules.order := {   echo shm_ipc.o;   echo boot_device_spi.o;   echo cpif.o; :; } > modules.order
