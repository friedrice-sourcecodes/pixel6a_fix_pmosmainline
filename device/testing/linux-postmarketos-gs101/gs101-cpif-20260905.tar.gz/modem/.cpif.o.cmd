savedcmd_cpif.o := ld.lld -EL  -maarch64elf -z norelro -z noexecstack   -r -o cpif.o @cpif.mod 
