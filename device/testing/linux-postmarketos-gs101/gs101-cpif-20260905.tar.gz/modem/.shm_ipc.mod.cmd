savedcmd_shm_ipc.mod := printf '%s\n'   shm_ipc.o | awk '!x[$$0]++ { print("./"$$0) }' > shm_ipc.mod
